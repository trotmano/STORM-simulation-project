function writeStormPointsForVisp(stormPoints,fname)
    stormPoints = [stormPoints,abs(randn(size(stormPoints,1),1))*0.5e4,zeros(size(stormPoints,1),1)];
    parts = strsplit(fname,'.'); 
    dlmwrite([parts{1},'_VispOutput.txt'],stormPoints,' ')
end