function printTriangles(triangles,fig)
    figure(fig)    
    hold on
    triangles = getMatrix(triangles);
    for i = 1:size(triangles,1)
        plot3(triangles(i,:,1),triangles(i,:,2),triangles(i,:,3))
%                 hold on
    end
end