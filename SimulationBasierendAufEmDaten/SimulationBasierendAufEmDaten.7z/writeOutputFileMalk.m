function writeOutputFileMalk(stormPoints,fname)
    stormPoints = [stormPoints,zeros(size(stormPoints,1),1),abs(randn(size(stormPoints,1),1))*0.5e4];
    parts = strsplit(fname,'.'); 
    dlmwrite([parts{1},'_MalkOutput.txt'],stormPoints,' ')
end