function main()
    figHandle = findobj('Type','figure');
    close(figHandle);
	rng(5);
    loa = 15; %length of both antibodies combined
    aoa = 90/180*pi; %angle of antibody
    bspnm = 0.27; %binding sites per nm
    pabs = 0.20; %part of available binding sites
    abpf = 12;% average blinking per fluorophor
    rof = 11;%radius of filament

    cEM = [0,0,0]; %color of EM data
    cSTORM = [1,0,0]; %color of STORM result
    cAB = [0,1,0]; %color of Antibody
    rSP = 10; %radius sphere for Storm loc aka localization precission
    rSPz = 20; %radius sphere for Storm loc in z
    sxy = 10; %sigma of fitting error in xy direction
    sz = 40; %sigma of fitting error in z direction
    
    bspsnm = .0159/2;
    %fname = 'Y:\Users_shared\Superresolution Simulation Software Project- Frank and Varun\Organelle Library\Microtubules\Microtubules.wimp';
    fname = 'Y:\Users_shared\Superresolution Simulation Software Project- Frank and Varun\Organelle Library\Mitochondria\Mitochondria-Tomogram-beta-islet-cells.nff';
    objects = importTriangles(fname);
    %objects = getActinRings({});
    %objects = getCrossingLines({});
    %objects = importEMData('141208-STORMmodel');
    %objects = importFilamentousStructures(fname);
    %objects = swapColumns(objects,2,3);
    objects = rescaleObjects(objects,10);
    if isSurfaceData(objects)
        [ap,ep] = findFluorophoresTri(objects, bspsnm, pabs, loa, aoa);
        idx = zeros(size(ep,1),1);
    else
        [ap,ep,idx]=findLines(objects, bspnm, pabs,aoa,loa,rof);
    end
    [stormPoints, idxF ,idxSt] = findStormPoints(ep, abpf, sxy, sz,idx,false);

    writeStormPointsForVisp(stormPoints,fname);
    writeOutputFileMalk(stormPoints,fname);
    writeStormPointsForAmira(stormPoints,fname);
    showEM(objects)
    showAntibodies(ap,ep)
    showEMAntibodies(objects,ap,ep)
    showStormPoints(stormPoints)
    showEMAntibodiesStormPoints(objects,ap,ep,stormPoints)

    setViewForFigures(150,30)
end

function showEMAntibodiesStormPoints(objects,ap,ep,stormPoints)
    fig = figure(findNextFigure);
    clf
    hold on
    if isSurfaceData(objects)
        printTriangles(objects,fig)
    else
        printEMLines(objects,fig,[0,0,0])
    end
    printAntibodies(ap, ep,fig, [0,1,0])
    printSTORMPoints(stormPoints,fig)
end

function showStormPoints(stormPoints)
    fig = figure(findNextFigure);
    clf
    hold on
    printSTORMPoints(stormPoints,fig)
end

function showEMAntibodies(objects,ap,ep)
    fig = figure(findNextFigure);
    clf
    hold on
    if isSurfaceData(objects)
        printTriangles(objects,fig)
    else
        printEMLines(objects,fig,[0,0,0])
    end
    printAntibodies(ap, ep,fig, [0,1,0])
end

function showAntibodies(ap,ep)
    fig = figure(findNextFigure);
    clf
    hold on
    printAntibodies(ap, ep,fig, [0,1,0])
end

function showEM(objects)
    fig = figure(findNextFigure);
    clf
    hold on
    if isSurfaceData(objects)
        printTriangles(objects,fig)
    else
        printEMLines(objects,fig,[0,0,0])
    end
end

function issd = isSurfaceData(objects)
    issd = 1;
    for i = 1:size(objects,2)
        if size(objects{i},1)>4
            issd = 0;
            break;
        end
    end
    issd
end

function idx = findNextFigure()
    figureHandles = findobj('Type','figure');
    if size(figureHandles) == 0
        idx = 1;
    else
        idx = max(figureHandles);
    end
end
